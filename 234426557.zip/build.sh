#!/usr/bin/sh
gcc -o assembler assembler.c assembler.h
gcc -o simulator simulator.c
